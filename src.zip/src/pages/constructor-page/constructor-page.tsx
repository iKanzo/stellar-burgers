import { useSelector } from '../../services/store';
import { selectIngredientsLoading } from '../../services/slices/ingredientsSlice';
import styles from './constructor-page.module.css';
import { BurgerConstructor, BurgerIngredients } from '@components';
import { Preloader } from '@ui';

export const ConstructorPage = () => {
  const isLoading = useSelector(selectIngredientsLoading);

  if (isLoading) {
    return (
      <div className={styles.preloaderContainer}>
        <Preloader />
      </div>
    );
  }

  return (
    <main className={styles.containerMain}>
      <h1
        className={`${styles.title} text text_type_main-large mt-10 mb-5 pl-5`}
      >
        Соберите бургер
      </h1>
      <div className={`${styles.main} pl-5 pr-5`}>
        <BurgerIngredients />
        <BurgerConstructor />
      </div>
    </main>
  );
};
